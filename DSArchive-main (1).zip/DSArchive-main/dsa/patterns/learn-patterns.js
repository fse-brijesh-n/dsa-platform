
// ============================================================
// GLOBAL STATE
// ============================================================
let syllabusData = { sections: [] };
let leetcodeIndex = {};
let completedTopics = new Set(JSON.parse(localStorage.getItem('learn_dsa_progress') || '[]'));
let certificateData = JSON.parse(localStorage.getItem('learn_dsa_certificate') || 'null');
let currentActiveTopic = null;
let popupCloseTimer = null;
let activePopupTitle = '';
let popupStateApplied = false;
let popupContentMap = {};
let popupRestoreState = null;

// ============================================================
// LOAD SYLLABUS
// ============================================================
async function loadSyllabus() {
    try {
    await loadLeetCodeIndex();
        const resp = await fetch('./learn-patterns-syllabus.json?' + Date.now());
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        syllabusData = await resp.json();
        console.log('✅ Loaded', syllabusData.sections.length, 'sections');
        buildSidebar();
        renderContent();
        updateProgress();
    } catch (err) {
        console.error('Failed to load syllabus:', err);
        document.getElementById('contentArea').innerHTML = `
            <div style="text-align:center;padding:3rem;color:var(--danger)">
                <i class="fas fa-exclamation-circle" style="font-size:2rem;margin-bottom:1rem"></i>
                <p>Failed to load syllabus data.</p>
                <p style="font-size:0.8rem;color:var(--text-muted)">Make sure <code>learn-patterns-syllabus.json</code> exists in the same folder.</p>
                <button class="btn" onclick="location.reload()" style="margin-top:1rem"><i class="fas fa-sync"></i> Retry</button>
            </div>`;
    }
}
async function loadLeetCodeIndex() {
  try {
    const resp = await fetch('../problems.json?' + Date.now());
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    leetcodeIndex = data.reduce((acc, item) => {
      const id = String(item.frontendQuestionId || '').trim();
      if (id) acc[id] = { slug: item.titleSlug, title: item.title };
      return acc;
    }, {});
  } catch (err) {
    console.warn('LeetCode index unavailable, using search fallback.');
    leetcodeIndex = {};
  }
}

function getLeetCodeUrl(id) {
  const entry = leetcodeIndex[id];
  if (entry && entry.slug) return `https://leetcode.com/problems/${entry.slug}/`;
  return `https://leetcode.com/problemset/?search=${encodeURIComponent(id)}`;
}


// ============================================================
// HELPERS
// ============================================================
function getTopicId(sectionId, topicName) {
    return (sectionId + '-' + topicName).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function openTopicPopup(title, bodyHtml) {
  applyPopupStateOnce();
  const popup = document.getElementById('topicPopup');
  document.getElementById('topicPopupTitle').textContent = title;
  const body = document.getElementById('topicPopupBody');
  body.innerHTML = bodyHtml;
  body.classList.remove('minimized');
  popup.classList.add('open');
  activePopupTitle = title;
}

function closeTopicPopup() {
  const popup = document.getElementById('topicPopup');
  popup.classList.remove('open');
  activePopupTitle = '';
}

function minimizeTopicPopup() {
  const popup = document.getElementById('topicPopup');
  const body = document.getElementById('topicPopupBody');
  const willMinimize = !popup.classList.contains('minimized-left');
  popup.classList.toggle('minimized-left', willMinimize);
  popup.classList.remove('maximized');
  body.classList.toggle('minimized', willMinimize);
  savePopupState();
}

function restoreTopicPopup() {
  const popup = document.getElementById('topicPopup');
  const body = document.getElementById('topicPopupBody');
  popup.classList.remove('minimized-left');
  body.classList.remove('minimized');
  savePopupState();
}

function schedulePopupClose() {
  clearTimeout(popupCloseTimer);
  popupCloseTimer = setTimeout(() => closeTopicPopup(), 500);
}

function cancelPopupClose() {
  clearTimeout(popupCloseTimer);
}

function applyPopupStateOnce() {
  if (popupStateApplied) return;
  popupStateApplied = true;
  const popup = document.getElementById('topicPopup');
  const body = document.getElementById('topicPopupBody');
  try {
    const raw = localStorage.getItem('learn_patterns_topic_popup');
    if (!raw) return;
    const state = JSON.parse(raw);
    if (state.width) popup.style.width = state.width + 'px';
    if (state.height) popup.style.height = state.height + 'px';
    if (typeof state.left === 'number' && typeof state.top === 'number') {
      popup.style.left = state.left + 'px';
      popup.style.top = state.top + 'px';
      popup.style.right = 'auto';
      popup.style.bottom = 'auto';
    }
    if (state.minimized) body.classList.add('minimized');
  } catch (err) {
    console.warn('Popup state load failed', err);
  }
}

function savePopupState() {
  const popup = document.getElementById('topicPopup');
  const body = document.getElementById('topicPopupBody');
  if (!popup) return;
  const rect = popup.getBoundingClientRect();
  const state = {
    width: Math.round(rect.width),
    height: Math.round(rect.height),
    left: Math.round(rect.left),
    top: Math.round(rect.top),
    minimized: body.classList.contains('minimized'),
  };
  localStorage.setItem('learn_patterns_topic_popup', JSON.stringify(state));
}

function togglePopupMaximize() {
  const popup = document.getElementById('topicPopup');
  const isMax = popup.classList.toggle('maximized');
  if (isMax) {
    popup.classList.remove('minimized-left');
    const rect = popup.getBoundingClientRect();
    popupRestoreState = {
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
    };
    popup.style.left = '0';
    popup.style.top = '0';
    popup.style.right = 'auto';
    popup.style.bottom = 'auto';
    popup.style.width = '100vw';
    popup.style.height = '100vh';
  } else if (popupRestoreState) {
    popup.style.left = popupRestoreState.left + 'px';
    popup.style.top = popupRestoreState.top + 'px';
    popup.style.right = 'auto';
    popup.style.bottom = 'auto';
    popup.style.width = popupRestoreState.width + 'px';
    popup.style.height = popupRestoreState.height + 'px';
  }
  savePopupState();
}

function saveProgress() {
    localStorage.setItem('learn_dsa_progress', JSON.stringify([...completedTopics]));
    updateProgress();
    buildSidebar();
}

function toggleTopic(topicId) {
    if (completedTopics.has(topicId)) completedTopics.delete(topicId);
    else completedTopics.add(topicId);
    saveProgress();
    renderContent();
}

function updateProgress() {
    let total = 0;
    syllabusData.sections.forEach(s => s.modules.forEach(m => total += m.topics.length));
    const pct = total > 0 ? Math.round((completedTopics.size / total) * 100) : 0;
    document.getElementById('globalProgress').style.width = pct + '%';
    document.getElementById('progressPercent').textContent = pct + '%';
    const certBtn = document.getElementById('certBtn');
    if (pct >= 100) {
        certBtn.classList.remove('locked');
        certBtn.innerHTML = certificateData ? '<i class="fas fa-certificate"></i> View Certificate' : '<i class="fas fa-certificate"></i> Get Certificate';
    } else {
        certBtn.classList.add('locked');
        certBtn.innerHTML = '<i class="fas fa-lock"></i> Complete 100% to Unlock';
    }
}

// ============================================================
// BUILD SIDEBAR
// ============================================================
function buildSidebar() {
    const nav = document.getElementById('sidebarNav');
    let html = '';
    syllabusData.sections.forEach((section, secIndex) => {
        let totalT = 0, doneT = 0;
        section.modules.forEach(m => {
            totalT += m.topics.length;
            m.topics.forEach(t => { if (completedTopics.has(getTopicId(section.id, t.name))) doneT++; });
        });
        const secPct = totalT > 0 ? Math.round((doneT / totalT) * 100) : 0;
        html += `<div class="nav-section">
            <div class="nav-section-title${secIndex > 0 ? ' collapsed' : ''}" onclick="toggleNavSection(this)">
                <span style="display:inline-flex;align-items:center;gap:0.4rem">
                    <span style="width:18px;height:18px;border-radius:0.3rem;display:inline-flex;align-items:center;justify-content:center;font-size:0.55rem;background:${section.color}15;color:${section.color};flex-shrink:0"><i class="fas ${section.icon}"></i></span>
                    ${section.name} <span style="font-size:0.55rem;opacity:0.7;font-weight:400;text-transform:none;letter-spacing:0">${doneT}/${totalT}</span>
                </span>
                <i class="fas fa-chevron-down arrow"></i>
            </div>
            <div style="margin:0 0.8rem 0.2rem;height:2px;background:rgba(255,255,255,0.04);border-radius:1px;overflow:hidden"><div style="height:100%;width:${secPct}%;background:${section.color};border-radius:1px;transition:width 0.5s;opacity:0.5"></div></div>
            <div class="nav-section-items${secIndex > 0 ? ' collapsed' : ''}" style="max-height:${totalT * 32}px">`;
        section.modules.forEach(mod => {
            html += `<div class="nav-module-label">${mod.name}</div>`;
            mod.topics.forEach(topic => {
                const tid = getTopicId(section.id, topic.name);
                const done = completedTopics.has(tid);
                const active = currentActiveTopic === tid ? ' active' : '';
                const doneClass = done ? ' completed' : '';
                html += `<a class="nav-item${active}${doneClass}" href="#${tid}" onclick="navigateToTopic('${section.id}','${topic.name.replace(/'/g,"\\'")}','${tid}')" title="${topic.name}"><i class="fas fa-check-circle ci"></i> ${topic.name}</a>`;
            });
        });
        html += '</div></div>';
    });
    nav.innerHTML = html;
}

function toggleNavSection(titleEl) {
    titleEl.classList.toggle('collapsed');
    let items = titleEl.nextElementSibling;
    if (items && !items.classList.contains('nav-section-items')) items = items.nextElementSibling;
    if (items && items.classList.contains('nav-section-items')) items.classList.toggle('collapsed');
}

function navigateToTopic(sectionId, topicName, topicId) {
    currentActiveTopic = topicId;
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    const item = document.querySelector(`.nav-item[href="#${topicId}"]`);
    if (item) item.classList.add('active');
    const el = document.getElementById(topicId);
    if (el) { el.scrollIntoView({behavior:'smooth',block:'center'}); el.style.boxShadow='0 0 0 3px rgba(96,165,250,0.3)'; setTimeout(()=>el.style.boxShadow='',1500); }
    document.getElementById('sidebar').classList.remove('open');
}

// ============================================================
// RENDER CONTENT
// ============================================================

    function renderContent() {
    let html = '<div class="welcome-section"><h1>Complete Learning Hub</h1><p>Master DSA Patterns with Company-wise preparation.</p></div>';
    const inlineLeetCodeLimit = 8;
    syllabusData.sections.forEach(section => {
        html += `<div class="syllabus-section"><h2><span class="section-icon" style="background:${section.color}15;color:${section.color}"><i class="fas ${section.icon}"></i></span> ${section.name}</h2>`;
        section.modules.forEach(mod => {
            html += `<div class="module-card"><h3 style="color:${section.color}">${mod.name}</h3>
                <table class="topic-table"><thead><tr><th style="width:40px">#</th><th>Topic</th><th style="width:380px">Actions</th></tr></thead><tbody>`;
            mod.topics.forEach(topic => {
                const tid = getTopicId(section.id, topic.name);
                const done = completedTopics.has(tid);
                const ytSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(topic.name+' '+section.name+' tutorial')}`;
                const gfgUrl = `https://www.geeksforgeeks.org/?s=${encodeURIComponent(topic.name)}`;
                const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(topic.name)}`;
                
                // Determine if subject is aptitude/reasoning/english vs programming/dsa
                const isNonProgramming = ['aptitude', 'reasoning', 'english'].includes(section.name.toLowerCase());
                
                // Google AI Mode URL - Universal Problem Solver
                const aiUrl = 'https://www.google.com/aimode?q=' +
                    encodeURIComponent(
                        'solve ' + (topic.name || '') + 
                        ' subject ' + (section.name || '') + ' provide detailed depth solution now. ' +
                        'your response must be focused structured and optimized. ' +
                        'output format requirements: ' +
                        '1) problem-understanding briefly explain in simple language clarify what is being asked mention common mistakes ' +
                        '2) edge-cases cover all important edge cases for this problem ' +
                        '3) ' + (isNonProgramming ? 'formula-approach' : 'pattern-identification') + ' identify exact ' + (isNonProgramming ? 'formula shortcut trick' : 'dsa pattern') + ' used explain why this approach mention alternatives and why less optimal ' +
                        '4) write ' + (isNonProgramming ? 'step-by-step calculation' : 'algorithm') + ' and provide brute force solution with code then dry-run step by step ' +
                        '5) ' + (isNonProgramming ? 'shortcut-method' : 'complexity-analysis') + ' clearly explain ' + (isNonProgramming ? 'fastest trick quick math approach' : 'time complexity space complexity why optimal worst case') + ' ' +
                        '6) generate optimal solution exactly for given problem provide most optimal code ' +
                        'act as senior expert solve given problem provide comprehensive response follow above 6 instructions. ' +
                        'rules: generate full response now no external links no videos no articles write everything here use tables full code'
                            .toLowerCase()
                            .replace(/[^a-z0-9\s]+/g, '')
                            .replace(/\s+/g, '-')
                            .replace(/^-|-$/g, '')
                    );
                
                let tooltipHTML = '';
                const leetList = (topic.leetcode || [])
                  .map(lc => String(lc).replace(/[^0-9]/g, '').trim())
                  .filter(Boolean);
                const inlineLeetList = leetList.slice(0, inlineLeetCodeLimit);
                const remainingLeetCount = Math.max(0, leetList.length - inlineLeetList.length);
                if (leetList.length > 0) {
                  tooltipHTML += '<div class="tooltip-section"><strong>LeetCode Problems</strong>';
                  tooltipHTML += '<table class="tooltip-table"><thead><tr><th>ID</th><th>Slug</th><th>Practice</th></tr></thead><tbody>';
                  leetList.forEach(n => {
                    const entry = leetcodeIndex[n];
                    const slug = entry && entry.slug ? entry.slug : '';
                    const url = getLeetCodeUrl(n);
                    const slugLabel = slug ? slug : `search-${n}`;
                    tooltipHTML += `<tr><td>#${n}</td><td><a href="${url}" target="_blank">${slugLabel}</a></td><td><a href="${url}" target="_blank">Practice</a></td></tr>`;
                  });
                  tooltipHTML += '</tbody></table></div>';
                } else {
                  tooltipHTML += '<div class="tooltip-section"><strong>Resources</strong>';
                  tooltipHTML += '<table class="tooltip-table"><thead><tr><th>Source</th><th>Link</th></tr></thead><tbody>';
                  tooltipHTML += `<tr><td>AI Mode</td><td><a href="${aiUrl}" target="_blank">Solve</a></td></tr>`;
                  tooltipHTML += '</tbody></table></div>';
                }
                if (topic.articles && topic.articles.length > 0) {
                  tooltipHTML += '<div class="tooltip-section"><strong>Articles</strong>';
                  tooltipHTML += '<table class="tooltip-table"><thead><tr><th>Link</th></tr></thead><tbody>';
                  topic.articles.forEach(a => { tooltipHTML += `<tr><td><a href="${a}" target="_blank">${a}</a></td></tr>`; });
                  tooltipHTML += '</tbody></table></div>';
                }
                html += `<tr id="${tid}" class="${done?'completed':''}">
                    <td class="check-cell"><input type="checkbox" ${done?'checked':''} onchange="toggleTopic('${tid}')"></td>
                    <td>
                      <span class="topic-name" data-popup-key="${tid}">${topic.name}</span>
                      ${inlineLeetList.length ? `<div class="leetcode-list">${inlineLeetList.map(n => `<a class="leetcode-chip" href="${getLeetCodeUrl(n)}" target="_blank">#${n}</a>`).join('')}${remainingLeetCount ? `<span class="leetcode-chip" title="${remainingLeetCount} more in popup">+${remainingLeetCount}</span>` : ''}</div>` : ''}
                    </td>
                    <td><div class="action-btns">
                        <a href="${topic.practice || aiUrl}" target="_blank" class="btn-nano btn-practice"><i class="fas fa-code"></i> Practice</a>
                        <a href="${topic.article}" target="_blank" class="btn-nano btn-article"><i class="fas fa-file-alt"></i> Article</a>
                        ${topic.videoId?`<button class="btn-nano btn-video" onclick="openVideo('${topic.videoId}')"><i class="fas fa-play"></i> Video</button>`:''}
                        <a href="${ytSearchUrl}" target="_blank" class="btn-nano btn-ytsearch"><i class="fab fa-youtube"></i> YT Search</a>
                        <a href="${aiUrl}" target="_blank" class="btn-nano btn-ai" style="background:rgba(168,85,247,0.1);color:#a855f7" title="Solve with AI"><i class="fas fa-robot"></i> AI Solve</a>
                    </div></td></tr>`;
            });
            html += '</tbody></table></div>';
        });
        html += '</div>';
    });
    document.getElementById('contentArea').innerHTML = html;

    popupContentMap = {};
    syllabusData.sections.forEach(section => {
      section.modules.forEach(mod => {
        mod.topics.forEach(topic => {
          const tid = getTopicId(section.id, topic.name);
          const leetList = (topic.leetcode || [])
            .map(lc => String(lc).replace(/[^0-9]/g, '').trim())
            .filter(Boolean);
          const ytSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(topic.name+' '+section.name+' tutorial')}`;
          const gfgUrl = `https://www.geeksforgeeks.org/?s=${encodeURIComponent(topic.name)}`;
          const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(topic.name)}`;
          const isNonProgramming = ['aptitude', 'reasoning', 'english'].includes(section.name.toLowerCase());
          const aiUrl = 'https://www.google.com/aimode?q=' +
            encodeURIComponent(
              'solve ' + (topic.name || '') +
              ' subject ' + (section.name || '') + ' provide detailed depth solution now. ' +
              'your response must be focused structured and optimized. ' +
              'output format requirements: ' +
              '1) problem-understanding briefly explain in simple language clarify what is being asked mention common mistakes ' +
              '2) edge-cases cover all important edge cases for this problem ' +
              '3) ' + (isNonProgramming ? 'formula-approach' : 'pattern-identification') + ' identify exact ' + (isNonProgramming ? 'formula shortcut trick' : 'dsa pattern') + ' used explain why this approach mention alternatives and why less optimal ' +
              '4) write ' + (isNonProgramming ? 'step-by-step calculation' : 'algorithm') + ' and provide brute force solution with code then dry-run step by step ' +
              '5) ' + (isNonProgramming ? 'shortcut-method' : 'complexity-analysis') + ' clearly explain ' + (isNonProgramming ? 'fastest trick quick math approach' : 'time complexity space complexity why optimal worst case') + ' ' +
              '6) generate optimal solution exactly for given problem provide most optimal code ' +
              'act as senior expert solve given problem provide comprehensive response follow above 6 instructions. ' +
              'rules: generate full response now no external links no videos no articles write everything here use tables full code'
                .toLowerCase()
                .replace(/[^a-z0-9\s]+/g, '')
                .replace(/\s+/g, '-')
                .replace(/^-|-$/g, '')
            );

          let popupHtml = '';
          if (leetList.length > 0) {
            popupHtml += '<div class="tooltip-section"><strong>LeetCode Problems</strong>';
            popupHtml += '<table class="tooltip-table"><thead><tr><th>ID</th><th>Slug</th><th>Practice</th></tr></thead><tbody>';
            leetList.forEach(n => {
              const entry = leetcodeIndex[n];
              const slug = entry && entry.slug ? entry.slug : '';
              const url = getLeetCodeUrl(n);
              const slugLabel = slug ? slug : `search-${n}`;
              popupHtml += `<tr><td>#${n}</td><td><a href="${url}" target="_blank">${slugLabel}</a></td><td><a href="${url}" target="_blank">Practice</a></td></tr>`;
            });
            popupHtml += '</tbody></table></div>';
          } else {
            popupHtml += '<div class="tooltip-section"><strong>Resources</strong>';
            popupHtml += '<table class="tooltip-table"><thead><tr><th>Source</th><th>Link</th></tr></thead><tbody>';
            popupHtml += `<tr><td>AI Mode</td><td><a href="${aiUrl}" target="_blank">Solve</a></td></tr>`;
            popupHtml += '</tbody></table></div>';
          }
          if (topic.articles && topic.articles.length > 0) {
            popupHtml += '<div class="tooltip-section"><strong>Articles</strong>';
            popupHtml += '<table class="tooltip-table"><thead><tr><th>Link</th></tr></thead><tbody>';
            topic.articles.forEach(a => { popupHtml += `<tr><td><a href="${a}" target="_blank">${a}</a></td></tr>`; });
            popupHtml += '</tbody></table></div>';
          }
          popupContentMap[tid] = { title: topic.name, body: popupHtml };
        });
      });
    });

    const contentArea = document.getElementById('contentArea');
    contentArea.addEventListener('click', (e) => {
      const el = e.target.closest('.topic-name');
      if (!el) return;
      e.preventDefault();
      e.stopPropagation();
      const key = el.getAttribute('data-popup-key');
      const payload = popupContentMap[key] || { title: 'Topic Details', body: '' };
      if (activePopupTitle === payload.title) {
        closeTopicPopup();
      } else {
        openTopicPopup(payload.title, payload.body);
      }
    });

    contentArea.addEventListener('touchstart', (e) => {
      const el = e.target.closest('.topic-name');
      if (!el) return;
      e.preventDefault();
      e.stopPropagation();
      const key = el.getAttribute('data-popup-key');
      const payload = popupContentMap[key] || { title: 'Topic Details', body: '' };
      if (activePopupTitle === payload.title) {
        closeTopicPopup();
      } else {
        openTopicPopup(payload.title, payload.body);
      }
    }, { passive: false });

    const popup = document.getElementById('topicPopup');
    popup.addEventListener('click', (e) => e.stopPropagation());
}

    
// function renderContent() {
//     let html = '<div class="welcome-section"><h1>Complete Learning Hub</h1><p>Master DSA Patterns with Company-wise preparation.</p></div>';
//     syllabusData.sections.forEach(section => {
//         html += `<div class="syllabus-section"><h2><span class="section-icon" style="background:${section.color}15;color:${section.color}"><i class="fas ${section.icon}"></i></span> ${section.name}</h2>`;
//         section.modules.forEach(mod => {
//             html += `<div class="module-card"><h3 style="color:${section.color}">${mod.name}</h3>
//                 <table class="topic-table"><thead><tr><th style="width:40px">#</th><th>Topic</th><th style="width:300px">Actions</th></tr></thead><tbody>`;
//             mod.topics.forEach(topic => {
//                 const tid = getTopicId(section.id, topic.name);
//                 const done = completedTopics.has(tid);
//                 const ytSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(topic.name+' '+section.name+' tutorial')}`;
//                 let tooltipHTML = '';
//                 if (topic.leetcode && topic.leetcode.length > 0) {
//                     tooltipHTML += '<div class="tooltip-section"><strong>Free LeetCode</strong>';
//                     topic.leetcode.forEach(lc => { const n = lc.replace(/[^0-9]/g,'').trim(); tooltipHTML += `<a href="https://leetcode.com/problems/${n}/" target="_blank">LeetCode #${n}</a>`; });
//                     tooltipHTML += '</div>';
//                 }
//                 if (topic.articles && topic.articles.length > 0) {
//                     tooltipHTML += '<div class="tooltip-section"><strong>Articles</strong>';
//                     topic.articles.forEach(a => tooltipHTML += `<a>· ${a}</a>`);
//                     tooltipHTML += '</div>';
//                 }
//                 html += `<tr id="${tid}" class="${done?'completed':''}">
//                     <td class="check-cell"><input type="checkbox" ${done?'checked':''} onchange="toggleTopic('${tid}')"></td>
//                     <td><span class="topic-name">${topic.name}${tooltipHTML?`<span class="topic-tooltip">${tooltipHTML}</span>`:''}</span></td>
//                     <td><div class="action-btns">
//                         <a href="${topic.practice}" target="_blank" class="btn-nano btn-practice"><i class="fas fa-code"></i> Practice</a>
//                         <a href="${topic.article}" target="_blank" class="btn-nano btn-article"><i class="fas fa-file-alt"></i> Article</a>
//                         ${topic.videoId?`<button class="btn-nano btn-video" onclick="openVideo('${topic.videoId}')"><i class="fas fa-play"></i> Video</button>`:''}
//                         <a href="${ytSearchUrl}" target="_blank" class="btn-nano btn-ytsearch"><i class="fab fa-youtube"></i> YT Search</a>
//                     </div></td></tr>`;
//             });
//             html += '</tbody></table></div>';
//         });
//         html += '</div>';
//     });
//     document.getElementById('contentArea').innerHTML = html;
// }

// ============================================================
// VIDEO MODAL
// ============================================================
const videoModal = document.getElementById('videoModal');
window.openVideo = function(videoId) {
    document.getElementById('videoContainer').innerHTML = `<iframe class="video-iframe" src="https://www.youtube.com/embed/${videoId}?autoplay=1&modestbranding=1&rel=0" allowfullscreen></iframe>`;
    videoModal.classList.add('active');
};
document.getElementById('closeModalBtn').addEventListener('click',()=>{videoModal.classList.remove('active');document.getElementById('videoContainer').innerHTML='';});
videoModal.addEventListener('click',function(e){if(e.target===videoModal){videoModal.classList.remove('active');document.getElementById('videoContainer').innerHTML='';}});

document.getElementById('topicPopupClose').addEventListener('click', (e) => { e.stopPropagation(); closeTopicPopup(); });
document.getElementById('topicPopupMin').addEventListener('click', (e) => { e.stopPropagation(); minimizeTopicPopup(); });
document.getElementById('topicPopupMax').addEventListener('click', (e) => { e.stopPropagation(); togglePopupMaximize(); });
document.getElementById('topicPopupRestore').addEventListener('click', (e) => { e.stopPropagation(); restoreTopicPopup(); });
document.addEventListener('click', (e) => {
  const popup = document.getElementById('topicPopup');
  if (!popup.classList.contains('open')) return;
  if (e.target.closest('.topic-name')) return;
  if (!popup.contains(e.target)) closeTopicPopup();
});

const popup = document.getElementById('topicPopup');
const popupHeader = document.querySelector('.topic-popup-header');
const resizeObserver = new ResizeObserver(() => savePopupState());
resizeObserver.observe(popup);

let isDraggingPopup = false;
let dragOffsetX = 0;
let dragOffsetY = 0;

// popupHeader.addEventListener('pointerdown', (e) => {
//   if (e.button !== 0) return;
//   isDraggingPopup = true;
//   const rect = popup.getBoundingClientRect();
//   dragOffsetX = e.clientX - rect.left;
//   dragOffsetY = e.clientY - rect.top;
//   popup.setPointerCapture(e.pointerId);
//   popup.style.right = 'auto';
//   popup.style.bottom = 'auto';
// });



popupHeader.addEventListener('pointerdown', (e) => {
  // Prevent drag when clicking on action buttons
  if (e.button !== 0) return;
  if (e.target.closest('.topic-popup-actions')) return;  // ✅ ADD THIS LINE
  isDraggingPopup = true;
  const rect = popup.getBoundingClientRect();
  dragOffsetX = e.clientX - rect.left;
  dragOffsetY = e.clientY - rect.top;
  popup.setPointerCapture(e.pointerId);
  popup.style.right = 'auto';
  popup.style.bottom = 'auto';
});



popup.addEventListener('pointermove', (e) => {
  if (!isDraggingPopup) return;
  popup.style.left = Math.max(8, e.clientX - dragOffsetX) + 'px';
  popup.style.top = Math.max(8, e.clientY - dragOffsetY) + 'px';
});

popup.addEventListener('pointerup', (e) => {
  if (!isDraggingPopup) return;
  isDraggingPopup = false;
  popup.releasePointerCapture(e.pointerId);
  savePopupState();
});

// ============================================================
// CERTIFICATE
// ============================================================
function showCertificate() {
    let total=0; syllabusData.sections.forEach(s=>s.modules.forEach(m=>total+=m.topics.length));
    if (Math.round((completedTopics.size/total)*100) < 100) { alert('Complete 100% of all topics to unlock the certificate!'); return; }
    if (!certificateData) {
        const name = prompt('Enter your full name for the certificate:');
        if (!name || !name.trim()) return;
        certificateData = {id:'DSARCHIVE-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).substring(2,6).toUpperCase(), name:name.trim(), date:new Date().toISOString()};
        localStorage.setItem('learn_dsa_certificate',JSON.stringify(certificateData));
        updateProgress();
    }
    document.getElementById('certNameDisplay').textContent = certificateData.name;
    document.getElementById('certIdDisplay').textContent = certificateData.id;
    document.getElementById('certOverlay').classList.add('active');
}
function closeCertificate() { document.getElementById('certOverlay').classList.remove('active'); }
document.getElementById('certOverlay').addEventListener('click',function(e){if(e.target===this)closeCertificate();});

// ============================================================
// SEARCH
// ============================================================
document.getElementById('searchInput').addEventListener('input',function(e){
    const term = e.target.value.toLowerCase(); if(!term||term.length<2)return;
    const all=[]; syllabusData.sections.forEach(s=>s.modules.forEach(m=>m.topics.forEach(t=>all.push({...t,sectionId:s.id}))));
    const found = all.find(t=>t.name.toLowerCase().includes(term));
    if(found){const tid=getTopicId(found.sectionId,found.name);navigateToTopic(found.sectionId,found.name,tid);}
});

// ============================================================
// THEME
// ============================================================
document.getElementById('themeToggle').addEventListener('click',function(){document.body.classList.toggle('light-mode');this.querySelector('i').classList.toggle('fa-moon');this.querySelector('i').classList.toggle('fa-sun');});

// ============================================================
// MOBILE
// ============================================================
document.getElementById('mobileToggle').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('keydown',function(e){
    if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();document.getElementById('searchInput').focus();}
    if(e.key==='Escape'){document.getElementById('sidebar').classList.remove('open');videoModal.classList.remove('active');closeCertificate();}
});

// ============================================================
// INIT
// ============================================================
window.toggleNavSection = toggleNavSection;
window.navigateToTopic = navigateToTopic;
loadSyllabus();
if(certificateData) updateProgress();
console.log('🚀 Learn DSA Patterns Ready');




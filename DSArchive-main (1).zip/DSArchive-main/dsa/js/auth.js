// ============================================================
// DSARCHIVE AUTH - /dsa/js/auth.js
// Public: /dsa/index.html, /dsa/learn-dsa.html, /dsa/dsa-concepts.html
// Protected: All other pages
// ============================================================

// Inject CSS
(function(){
    const css = `
        #dsa-force-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:99999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);}
        #dsa-force-popup{background:#0f172a;border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:36px 28px;text-align:center;max-width:400px;width:90%;box-shadow:0 30px 60px rgba(0,0,0,0.7);position:absolute;cursor:grab;user-select:none;}
        #dsa-force-popup.dragging{cursor:grabbing!important;}
        #dsa-force-popup h2{color:#e2e8f0;margin:0 0 4px;font-size:1.15rem;}
        #dsa-force-popup p{color:#94a3b8;font-size:0.78rem;margin:0 0 18px;}
        #dsa-force-popup .min-btn{position:absolute;top:8px;left:12px;background:none;border:none;color:#64748b;cursor:pointer;font-size:0.8rem;}
        #dsa-force-mini-bar{position:fixed;top:50%;left:-28px;transform:translateY(-50%);z-index:99998;background:rgba(15,23,42,0.85);padding:8px 6px;border-radius:0 10px 10px 0;cursor:pointer;border:1px solid rgba(255,255,255,0.08);border-left:none;display:none;writing-mode:vertical-rl;font-size:0.55rem;color:#94a3b8;letter-spacing:1px;transition:left 0.3s;}
        #dsa-force-mini-bar:hover{left:0;}
        #dsa-force-mini-bar.show{display:flex;}
        .dsa-badge{position:fixed;top:16px;right:16px;z-index:9999;display:flex;align-items:center;gap:6px;background:rgba(15,23,42,0.7);backdrop-filter:blur(12px);padding:4px 10px;border-radius:30px;border:1px solid rgba(255,255,255,0.06);user-select:none;cursor:grab;}
        .dsa-badge:hover{background:rgba(15,23,42,0.85);border-color:rgba(255,255,255,0.12);}
        .dsa-badge.dragging{cursor:grabbing!important;}
        .dsa-badge img{width:22px;height:22px;border-radius:50%;flex-shrink:0;pointer-events:none;}
        .dsa-badge .badge-name{font-size:0.68rem;color:#e2e8f0;white-space:nowrap;pointer-events:none;}
        .dsa-badge .logout-btn{padding:3px 8px;border-radius:15px;cursor:pointer;font-size:0.6rem;border:1px solid rgba(239,68,68,0.2);background:rgba(239,68,68,0.08);color:#fca5a5;}
        .dsa-badge .login-btn{padding:4px 10px;border-radius:15px;cursor:pointer;font-size:0.65rem;border:1px solid rgba(59,130,246,0.2);background:rgba(59,130,246,0.08);color:#93c5fd;}
        .dsa-badge .min-btn{padding:0 4px;cursor:pointer;font-size:0.55rem;color:#64748b;background:none;border:none;line-height:1;}
        .dsa-badge .min-btn:hover{color:#e2e8f0;}
        .dsa-badge.mini{padding:4px 8px!important;gap:4px!important;border-radius:50%!important;width:30px!important;height:30px!important;justify-content:center!important;}
        .dsa-badge.mini span,.dsa-badge.mini .logout-btn,.dsa-badge.mini .login-btn,.dsa-badge.mini .min-btn,.dsa-badge.mini .badge-name{display:none!important;}
        .dsa-badge.mini img{display:block!important;}
        .dsa-opt-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:99999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
        .dsa-opt-overlay .popup-box{background:#0f172a;border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:28px 22px;text-align:center;max-width:360px;width:90%;box-shadow:0 20px 50px rgba(0,0,0,0.6);position:relative;}
        .dsa-opt-overlay h2{color:#e2e8f0;margin:0 0 4px;font-size:1rem;}
        .dsa-opt-overlay p{color:#94a3b8;font-size:0.7rem;margin:0 0 14px;}
        .dsa-opt-overlay .close-btn{position:absolute;top:10px;right:12px;background:none;border:none;color:#64748b;cursor:pointer;font-size:1rem;}
        .dsa-opt-overlay .close-btn:hover{color:#f87171;}
        .credit-text{font-size:0.55rem;color:#64748b;margin-top:12px;}
    `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
})();

// Main auth logic
(function(){
    const CLIENT_ID = '868197425269-foo4k3mudhtqk9to6vn2jpe7m2sq3rj5.apps.googleusercontent.com';
    const KEY = 'dsa_user';
    
    // Pages that do NOT require forced login
    const PUBLIC = [
        '/dsa/problemset.html',
        '/dsa/problems.html',
        '/dsa/index.html', '/dsa/','/dsa',
        '/dsa/learn-dsa.html', '/dsa/dsa-concepts.html',
        '/dsa/patterns/learn-patterns.html'
    ];
    const FORCE_LOGIN = !PUBLIC.includes(window.location.pathname);

    function getUser(){ try{ return JSON.parse(localStorage.getItem(KEY)); }catch(e){ return null; } }
    function saveUser(u){ u.time = Date.now(); localStorage.setItem(KEY, JSON.stringify(u)); }
    function parseJwt(t){ return JSON.parse(atob(t.split('.')[1])); }

    const user = getUser();
    const isLoggedIn = user && (Date.now() - user.time < 86400000);

    // ═══════════════════════════════════════════════
    // FLOW 1: FORCED LOGIN (for non‑public pages)
    // If the page requires login (FORCE_LOGIN=true) AND user is not logged in,
    // show a full‑screen overlay and do nothing else until they sign in.
    // ═══════════════════════════════════════════════
    if (FORCE_LOGIN && !isLoggedIn) {
        const overlay = document.createElement('div');
        overlay.id = 'dsa-force-overlay';
        overlay.innerHTML = `<div id="dsa-force-popup"><button class="min-btn" title="Minimize">─</button><div style="font-size:2.5rem;margin-bottom:8px;">🔐</div><h2>Sign in Required</h2><p>Login with Google to access this page</p><div id="dsa-force-g-btn" style="display:flex;justify-content:center;min-height:42px;"></div><p class="credit-text">Powered by Tecresearch</p></div>`;
        document.body.appendChild(overlay);
        
        const miniBar = document.createElement('div');
        miniBar.id = 'dsa-force-mini-bar';
        miniBar.textContent = '🔐';
        document.body.appendChild(miniBar);
        document.body.style.overflow = 'hidden';
        const popup = document.getElementById('dsa-force-popup');

        miniBar.onclick = function(){ popup.style.display='flex'; miniBar.classList.remove('show'); };
        popup.querySelector('.min-btn').addEventListener('click',function(e){ e.stopPropagation(); popup.style.display='none'; miniBar.classList.add('show'); });
        popup.addEventListener('dblclick',function(e){ if(e.target.tagName!=='BUTTON'){popup.style.display='none';miniBar.classList.add('show');} });

        let d=false,sx,sy,sl,st;
        popup.addEventListener('mousedown',function(e){if(e.target.tagName==='BUTTON')return;d=true;popup.classList.add('dragging');var r=popup.getBoundingClientRect();sx=e.clientX;sy=e.clientY;sl=r.left;st=r.top;popup.style.position='fixed';popup.style.left=sl+'px';popup.style.top=st+'px';popup.style.transform='none';popup.style.margin='0';e.preventDefault();});
        document.addEventListener('mousemove',function(e){if(!d)return;popup.style.left=(sl+e.clientX-sx)+'px';popup.style.top=(st+e.clientY-sy)+'px';});
        document.addEventListener('mouseup',function(){d=false;popup.classList.remove('dragging');});

        function renderGSI(){
            if(typeof google!=='undefined'&&google.accounts){
                google.accounts.id.initialize({
                    client_id:CLIENT_ID,
                    callback:function(r){
                        var p=parseJwt(r.credential);
                        saveUser({name:p.name,email:p.email,picture:p.picture,id:p.sub});
                        localStorage.setItem('dsa_token', r.credential);  // store ID token for API
                        location.reload();
                    }
                });
                google.accounts.id.renderButton(document.getElementById('dsa-force-g-btn'),{theme:'filled_blue',size:'large',shape:'pill',text:'signin_with'});
            }
        }
        if(typeof google!=='undefined'&&google.accounts)renderGSI();
        else{var s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.onload=renderGSI;document.head.appendChild(s);}
        return;   // <-- stop here; the rest of the script (badge, auto‑refresh) does NOT run on forced pages
    }

    // ═══════════════════════════════════════════════
    // FLOW 2: OPTIONAL LOGIN (public pages, or already logged in)
    // Show a small draggable badge with login/logout button.
    // If the user is logged in but the API token is missing,
    // the auto‑refresh block at the bottom will silently obtain it.
    // ═══════════════════════════════════════════════
    const badge = document.createElement('div');
    badge.className = 'dsa-badge';

    function renderBadge(){
        const u=getUser();
        const logged=u&&(Date.now()-u.time<86400000);
        if(logged){
            badge.innerHTML=`<img src="${u.picture}" draggable="false"><span class="badge-name">${u.name.split(' ')[0]}</span><button class="min-btn" title="Minimize">─</button><button class="logout-btn">Logout</button>`;
            badge.querySelector('.logout-btn').addEventListener('click',function(e){e.stopPropagation();localStorage.removeItem(KEY);localStorage.removeItem('dsa_token');location.reload();});
        } else {
            badge.innerHTML=`<button class="min-btn" title="Minimize">─</button><button class="login-btn">🔐 Login</button>`;
            badge.querySelector('.login-btn').addEventListener('click',function(e){e.stopPropagation();openLoginPopup();});
        }
    }
    renderBadge();
    document.body.appendChild(badge);

    // Badge drag & minimize functionality (unchanged)
    badge.addEventListener('click',function(e){if(e.target.classList.contains('min-btn')){e.stopPropagation();badge.classList.toggle('mini');}});
    badge.addEventListener('dblclick',function(e){if(e.target.tagName!=='BUTTON')badge.classList.toggle('mini');});

    let bd=false,bsx,bsy,bsl,bst;
    badge.addEventListener('mousedown',function(e){if(e.target.classList.contains('logout-btn')||e.target.classList.contains('login-btn'))return;bd=true;badge.classList.add('dragging');var r=badge.getBoundingClientRect();bsx=e.clientX;bsy=e.clientY;bsl=r.left;bst=r.top;badge.style.right='auto';badge.style.left=bsl+'px';badge.style.top=bst+'px';badge.style.transition='none';e.preventDefault();});
    document.addEventListener('mousemove',function(e){if(!bd)return;badge.style.left=(bsl+e.clientX-bsx)+'px';badge.style.top=(bst+e.clientY-bsy)+'px';});
    document.addEventListener('mouseup',function(){bd=false;badge.classList.remove('dragging');badge.style.transition='';});

    // Optional login popup (when badge "Login" is clicked)
    window.openLoginPopup=function(){
        var old=document.getElementById('dsa-opt-overlay');if(old)old.remove();
        var overlay=document.createElement('div');overlay.id='dsa-opt-overlay';overlay.className='dsa-opt-overlay';
        overlay.innerHTML=`<div class="popup-box"><button class="close-btn">✕</button><div style="font-size:2rem;margin-bottom:6px;">👋</div><h2>Sign in to DSArchive</h2><p>Save your progress across devices</p><div id="dsa-opt-g-btn" style="display:flex;justify-content:center;min-height:38px;"></div><p class="credit-text">Powered by Tecresearch</p></div>`;
        overlay.querySelector('.close-btn').addEventListener('click',function(){overlay.remove();});
        overlay.addEventListener('click',function(e){if(e.target===overlay)overlay.remove();});
        document.body.appendChild(overlay);
        function renderOptGSI(){
            if(typeof google!=='undefined'&&google.accounts){
                google.accounts.id.initialize({
                    client_id:CLIENT_ID,
                    callback:function(r){
                        var p=parseJwt(r.credential);
                        saveUser({name:p.name,email:p.email,picture:p.picture,id:p.sub});
                        localStorage.setItem('dsa_token', r.credential);  // store ID token for API
                        location.reload();
                    }
                });
                google.accounts.id.renderButton(document.getElementById('dsa-opt-g-btn'),{theme:'filled_blue',size:'medium',shape:'pill',text:'signin_with'});
            }
        }
        if(typeof google!=='undefined'&&google.accounts){google.accounts.id.cancel();renderOptGSI();}
        else{var s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.onload=renderOptGSI;document.head.appendChild(s);}
    };

    // ═══════════════════════════════════════════════
    // AUTO‑REFRESH TOKEN
    // If user is logged in (dsa_user exists) but the API token (dsa_token) is
    // missing (e.g., because they logged in before we started saving tokens),
    // silently ask Google for a new ID token and reload the page.
    // This block runs on PUBLIC pages and on already‑logged‑in protected pages.
    // ═══════════════════════════════════════════════
    (function initTokenRefresh() {
        if (localStorage.getItem('dsa_token')) return;   // token already present, nothing to do
        const u = getUser();
        if (!u) return;   // not logged in at all, nothing to refresh

        function tryGetToken() {
            if (typeof google !== 'undefined' && google.accounts && google.accounts.id) {
                google.accounts.id.initialize({
                    client_id: CLIENT_ID,
                    callback: function(r) {
                        localStorage.setItem('dsa_token', r.credential);
                        console.log('✅ Token refreshed automatically');
                        location.reload();
                    },
                    ux_mode: 'popup'
                });
                google.accounts.id.prompt();
            } else {
                setTimeout(tryGetToken, 500);
            }
        }
        setTimeout(tryGetToken, 1000);
    })();


     // Force load Google library on all pages
    (function() {
        if (!document.querySelector('script[src="https://accounts.google.com/gsi/client"]')) {
            var s = document.createElement('script');
            s.src = 'https://accounts.google.com/gsi/client';
            s.async = true;
            document.head.appendChild(s);
        }
    })();


})();




// ============================================================
// DSARCHIVE AUTH - /dsa/js/auth.js
// Public: /dsa/index.html, /dsa/learn-dsa.html, /dsa/dsa-concepts.html
// Protected: All other pages
// ============================================================

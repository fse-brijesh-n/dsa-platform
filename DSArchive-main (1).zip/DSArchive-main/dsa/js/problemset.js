
// ═══════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════

// const API_URL = 'https://script.google.com/macros/s/AKfycbwIYDVEL-_dufPF49frqKeK4Py7Yza_sD-jaFIOwzlix68ktpB8vgI8086OqHPZMi21qA/exec';

const LIMIT = 40;
const CLIENT_ID = '868197425269-foo4k3mudhtqk9to6vn2jpe7m2sq3rj5.apps.googleusercontent.com';

// ═══════════════════════════════════════
// STATE
// ═══════════════════════════════════════
// window.allProblems = [];
// let serverSolved = new Set();
// let serverFavs = new Set();
// let serverStreak = 0;
// let curPage = 1, curPattern = 'All', curDiff = 'All', curSearch = '';


window.allProblems = [];
window.serverSolved = new Set();
window.serverFavs = new Set();
window.serverStreak = 0;

window.curPage = 1;
window.curPattern = 'All';
window.curDiff = 'All';
window.curSearch = '';


const ALL_PATTERNS = [
    'Array', 'String', 'Hash Table', 'Two Pointers', 'Sliding Window', 'Binary Search', 'Sorting',
    'Prefix Sum', 'Matrix', 'Simulation', 'Enumeration', 'Greedy', 'Bit Manipulation', 'Math',
    'Recursion', 'Backtracking', 'Divide and Conquer', 'Dynamic Programming', 'Stack', 'Queue',
    'Heap (Priority Queue)', 'Linked List', 'Tree', 'Binary Tree', 'Depth-First Search',
    'Breadth-First Search', 'Graph', 'Memoization', 'Monotonic Stack', 'Monotonic Queue',
    'Doubly-Linked List', 'Merge Intervals', 'Cyclic Sort', 'In-place Reversal',
    'Binary Search Tree', 'Tree Traversal', 'Trie', 'Union Find', 'Topological Sort',
    'Shortest Path', 'Dijkstra', 'Connected Components', 'Island Problems', 'Flood Fill',
    'Disjoint Set', 'Intervals', 'Sweep Line', 'Line Sweep', 'Geometry', 'Randomized',
    'Reservoir Sampling', 'Probability', 'Game Theory', 'Combinatorics', 'Number Theory',
    'Modular Arithmetic', 'Rolling Hash', 'Rabin-Karp', 'KMP', 'Z Algorithm',
    'String Matching', 'Palindrome', 'Subsequence', 'Subset', 'Permutation', 'Knapsack',
    'Design', 'Segment Tree', 'Fenwick Tree', 'Bellman-Ford', 'Floyd Warshall',
    'Minimum Spanning Tree', 'Kruskal', 'Prim', 'Eulerian Path',
    'Strongly Connected Components', 'Tarjan Algorithm', 'Kosaraju Algorithm',
    'Articulation Point', 'Bridge Finding', 'Convex Hull', 'Manacher Algorithm',
    'Digit DP', 'Bitmask DP', 'State Machine DP', 'Meet in the Middle', 'Max Flow',
    'Min Cost Max Flow', 'Database', 'Concurrency', 'Interactive'
];

const PATTERN_COLORS = [
    '#ff6b6b', '#feca57', '#48dbfb', '#ff9ff3', '#54a0ff', '#5f27cd', '#01a3a4', '#f368e0',
    '#ff6348', '#7bed9f', '#70a1ff', '#5352ed', '#ff4757', '#2ed573', '#1e90ff', '#ffa502',
    '#a4b0be', '#57606f', '#e056a0', '#22a6b3', '#be2edd', '#4834d4', '#badc58', '#f9ca24',
    '#f0932b', '#eb4d4b', '#6ab04c', '#c7ecee', '#dff9fb', '#30336b'
];

// ═══════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════
async function waitForGoogleLibrary(timeout = 5000) {
    if (!document.querySelector('script[src="https://accounts.google.com/gsi/client"]')) {
        const script = document.createElement('script');
        script.src = 'https://accounts.google.com/gsi/client';
        script.async = true;
        document.head.appendChild(script);
    }
    const start = Date.now();
    while (!window.google?.accounts?.id) {
        if (Date.now() - start > timeout) return false;
        await new Promise(r => setTimeout(r, 200));
    }
    return true;
}

function getToken() {
    return localStorage.getItem('dsa_token');
}



// BUG FIXED by nodejs proxy server


const PROXY_URL = 'https://dsarchive-proxy-server.onrender.com/api';

async function apiCall(action, data = {}) {
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    data.token = token;
    data.action = action;

    const resp = await fetch(PROXY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    if (!resp.ok) {
        const errText = await resp.text();
        throw new Error(`API error ${resp.status}: ${errText}`);
    }
    return resp.json();
}




async function attemptSilentToken() {
    return new Promise((resolve) => {
        try {
            google.accounts.id.initialize({
                client_id: CLIENT_ID,
                callback: (r) => {
                    localStorage.setItem('dsa_token', r.credential);
                    resolve(r.credential);
                },
                ux_mode: 'popup'
            });
            google.accounts.id.prompt((notif) => {
                if (notif.isNotDisplayed() || notif.isSkippedMoment()) resolve(null);
                else if (notif.isDismissedMoment()) resolve(null);
            });
        } catch (e) { resolve(null); }
    });
}

// ═══════════════════════════════════════
// DATA LOADING
// ═══════════════════════════════════════
async function loadUserData() {
    if (!getToken()) return;
    try {
        const resp = await apiCall('getUserData');
        if (resp && !resp.error) {
            serverSolved = new Set(resp.solved);
            serverFavs = new Set(resp.favorites);
            serverStreak = resp.streak || 0;
        }
    } catch (e) { console.error(e); }
    updateStats();
    applyFilters();
    renderFavsSidebar();
    fetchLeaderboard();
}

// ═══════════════════════════════════════
// TOGGLES
// ═══════════════════════════════════════
async function toggleSolvedAPI(pid, problem, checkbox) {
    if (!getToken()) { alert('Login first'); checkbox.checked = !checkbox.checked; return; }
    checkbox.disabled = true;
    try {
        const resp = await apiCall('toggleSolved', {
            problem: {
                frontendQuestionId: pid,
                title: problem.title,
                difficulty: problem.difficulty,
                topicTags: (problem.topicTags || []).map(t => typeof t === 'string' ? t : t.name),
                isPotd: false
            }
        });
        if (!resp.error) {
            serverSolved = new Set(resp.solved);
            serverFavs = new Set(resp.favorites);
            serverStreak = resp.streak || serverStreak;
            updateStats();
            applyFilters();
        } else checkbox.checked = !checkbox.checked;
    } catch (e) { checkbox.checked = !checkbox.checked; }
    checkbox.disabled = false;
}

async function toggleFavoriteAPI(pid) {
    if (!getToken()) { alert('Login first'); return; }
    try {
        const resp = await apiCall('toggleFavorite', { problemId: pid });
        if (!resp.error) {
            serverFavs = new Set(resp.favorites);
            updateStats();
            applyFilters();
            renderFavsSidebar();
        }
    } catch (e) { alert('Failed'); }
}

// ═══════════════════════════════════════
// POTD
// ═══════════════════════════════════════
async function markPotdSolved() {
    if (!getToken()) { alert('Login first'); return; }
    const potd = getCurrentPotd();
    if (!potd) return;
    const btn = document.getElementById('potdSolvedBtn');
    btn.disabled = true;
    try {
        const resp = await apiCall('markPotdSolved', {
            problem: {
                frontendQuestionId: potd.frontendQuestionId,
                title: potd.title,
                difficulty: potd.difficulty,
                topicTags: (potd.topicTags || []).map(t => t.name),
                link: `https://leetcode.com/problems/${potd.titleSlug}/`
            }
        });
        if (!resp.error) {
            serverSolved = new Set(resp.solved);
            serverStreak = resp.streak || serverStreak;
            updateStats();
            applyFilters();
            alert('🔥 Streak updated!');
        }
    } catch (e) { alert('Failed'); }
    btn.disabled = false;
}


//     async function markPotdSolved() {
//     if (!getToken()) { alert('Login first'); return; }
//     const potd = getCurrentPotd();
//     if (!potd) return;
//     const btn = document.getElementById('potdSolvedBtn');
//     btn.disabled = true;
//     try {
//         const today = new Date().toISOString().split('T')[0];   // e.g. "2026-05-08"
//         const resp = await apiCall('markPotdSolved', {
//             problem: {
//                 frontendQuestionId: potd.frontendQuestionId,
//                 title: potd.title,
//                 difficulty: potd.difficulty,
//                 topicTags: (potd.topicTags || []).map(t => t.name),
//                 link: `https://leetcode.com/problems/${potd.titleSlug}/`
//             },
//             date: today                                           // <-- this is new
//         });
//         if (!resp.error) {
//             serverSolved = new Set(resp.solved);
//             serverStreak = resp.streak || serverStreak;
//             updateStats();
//             applyFilters();
//             alert('🔥 Streak updated!');
//         }
//     } catch (e) { alert('Failed'); }
//     btn.disabled = false;
// }



function getCurrentPotd() {
    if (!window.allProblems.length) return null;
    const ds = new Date().toISOString().split('T')[0];
    let h = 0;
    for (let i = 0; i < ds.length; i++) { h = ((h << 5) - h) + ds.charCodeAt(i); h |= 0; }
    return window.allProblems[Math.abs(h) % window.allProblems.length];
}

// ═══════════════════════════════════════
// LEADERBOARD
// ═══════════════════════════════════════
async function fetchLeaderboard() {
    const lbList = document.getElementById('lbList');
    if (!getToken()) {
        lbList.innerHTML = '<div style="text-align:center;color:var(--text-muted);">Login to view leaderboard</div>';
        return;
    }
    try {
        const leaders = await apiCall('getLeaderboard');
        renderLeaderboard(leaders);
    } catch (e) {
        lbList.innerHTML = '<div style="text-align:center;color:var(--hard);">Team is working activity to fix the new features</div>';
    }
}

function renderLeaderboard(users) {
    const list = document.getElementById('lbList');
    if (!users || !users.length) {
        list.innerHTML = '<div style="text-align:center;color:var(--text-muted);">No data</div>';
        return;
    }
    list.innerHTML = users.slice(0, 10).map((u, i) => `
                <div class="lb-row" onclick="showUserDetail('${u.userId}')">
                    <span class="lb-rank">${i + 1}</span>
                    <img class="lb-avatar" src="${u.picture}" onerror="this.style.display='none'">
                    <span class="lb-name">${u.name.split(' ')[0]}</span>
                    <span class="lb-streak">🔥 ${u.streak}</span>
                    <span class="lb-solved">✓ ${u.solved}</span>
                </div>
            `).join('');
}

// ═══════════════════════════════════════
// USER DETAIL MODAL
// ═══════════════════════════════════════
async function showUserDetail(userId) {
    if (!getToken()) return;
    const modal = document.getElementById('userModal');
    const inner = document.getElementById('userModalInner');
    inner.innerHTML = 'Loading...';
    modal.classList.add('show');
    try {
        const resp = await apiCall('getUserDetail', { targetUserId: userId });
        if (resp && resp.user) {
            const u = resp.user;
            const actMap = u.activity || {};
            const calHtml = buildActivityCalendar(new Date().getFullYear(), actMap);
            inner.innerHTML = `
                        <div style="display:flex; gap:12px; align-items:center;">
                            <img src="${u.picture}" style="width:40px;height:40px;border-radius:50%">
                            <div><strong>${u.name}</strong><br><span style="font-size:0.7rem;">🔥 Streak: ${u.streak} (max ${u.maxStreak})</span></div>
                        </div>
                        <div style="margin:12px 0;"><span>✅ Solved: ${u.solvedCount}</span> &nbsp; <span>⭐ Favorites: ${u.favorites.length}</span></div>
                        <h4>Activity</h4><div class="calendar-grid">${calHtml}</div>
                        <div style="margin-top:10px; max-height:200px; overflow-y:auto;">
                            <h4>Recent Solved</h4>
                            <ul style="list-style:none; padding:0;">${(u.solvedProblems || []).slice(-20).reverse().map(p => `<li style="font-size:0.7rem;">#${p.problemId} ${p.title} <span style="color:var(--easy)">${p.difficulty}</span></li>`).join('')}</ul>
                        </div>`;
        } else inner.innerHTML = 'User not found';
    } catch (e) { inner.innerHTML = 'Error loading details'; }
}

function buildActivityCalendar(year, activityMap) {
    let html = '';
    for (let m = 0; m < 12; m++) {
        const dim = new Date(year, m + 1, 0).getDate();
        for (let d = 1; d <= dim; d++) {
            const ds = `${year}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            html += `<div class="cal-day ${activityMap[ds] ? 'active' : 'inactive'}" title="${ds}"></div>`;
        }
    }
    return html;
}

function closeUserModal() { document.getElementById('userModal').classList.remove('show'); }

// ═══════════════════════════════════════
// PATTERNS
// ═══════════════════════════════════════
function getPatternCounts() {
    const map = {};
    window.allProblems.forEach(p => {
        (p.topicTags || []).forEach(t => {
            const name = t.name || t;
            map[name] = (map[name] || 0) + 1;
        });
    });
    return Object.entries(map).sort((a, b) => {
        const ai = ALL_PATTERNS.indexOf(a[0]), bi = ALL_PATTERNS.indexOf(b[0]);
        if (ai >= 0 && bi < 0) return -1;
        if (ai < 0 && bi >= 0) return 1;
        if (ai >= 0 && bi >= 0) return ai - bi;
        return b[1] - a[1];
    });
}

function buildPatterns() {
    const counts = getPatternCounts();
    let sideHtml = `<div class="pattern-item active" onclick="selPattern('All')" data-p="All"><span style="color:var(--accent);">●</span> All Problems <span class="cnt">${window.allProblems.length}</span></div>`;
    counts.forEach(([name, cnt], i) => {
        const c = PATTERN_COLORS[i % PATTERN_COLORS.length];
        sideHtml += `<div class="pattern-item" onclick="selPattern('${name}')" data-p="${name}"><span style="color:${c};">●</span> ${name} <span class="cnt">${cnt}</span></div>`;
    });
    document.getElementById('patternList').innerHTML = sideHtml;
    document.getElementById('patternPills').innerHTML = `<span class="pattern-pill active" onclick="selPattern('All')">All</span>` + counts.slice(0, 35).map(([name]) => `<span class="pattern-pill" onclick="selPattern('${name}')">${name}</span>`).join('');
}

function selPattern(p) {
    curPattern = p; curPage = 1;
    document.querySelectorAll('.pattern-item,.pattern-pill').forEach(el => el.classList.toggle('active', el.dataset.p === p || el.textContent.trim().startsWith(p)));
    applyFilters();
    if (window.innerWidth <= 1024) closeSidebar();
}

// ═══════════════════════════════════════
// FILTER & RENDER
// ═══════════════════════════════════════
function getFiltered() {
    let f = [...window.allProblems];
    if (curPattern !== 'All') f = f.filter(p => (p.topicTags || []).some(t => (t.name || t) === curPattern));
    if (curDiff !== 'All') f = f.filter(p => p.difficulty === curDiff);
    if (curSearch.trim()) {
        const s = curSearch.toLowerCase().trim();
        f = f.filter(p => p.title.toLowerCase().includes(s) || String(p.frontendQuestionId).includes(s) || p.titleSlug.toLowerCase().includes(s) || p.difficulty.toLowerCase().includes(s) || (p.topicTags || []).some(t => (t.name || t).toLowerCase().includes(s)));
    }
    return f;
}

function applyFilters() {
    const filtered = getFiltered();
    const totalPages = Math.ceil(filtered.length / LIMIT) || 1;
    if (curPage > totalPages) curPage = totalPages;
    const start = (curPage - 1) * LIMIT;
    const page = filtered.slice(start, start + LIMIT);
    document.getElementById('searchInfo').innerHTML = [
        curPattern !== 'All' ? `Pattern: <b>${curPattern}</b>` : '',
        curDiff !== 'All' ? `Difficulty: <b>${curDiff}</b>` : '',
        curSearch ? `Search: "<b>${curSearch}</b>"` : '',
        `<b>${filtered.length}</b> results`
    ].filter(Boolean).join(' • ');
    renderTable(page);
    renderPagination(totalPages);
    updateStats();
}

function renderTable(problems) {
    const tb = document.getElementById('tableBody');
    if (!problems.length) {
        tb.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No problems match.</td></tr>';
        return;
    }
    tb.innerHTML = problems.map(p => {
        const pid = p.frontendQuestionId || p.titleSlug;
        const slv = serverSolved.has(pid), fv = serverFavs.has(pid);
        const lc = `https://leetcode.com/problems/${p.titleSlug}/`;
        const ai = `https://www.google.com/aimode?q=${encodeURIComponent('solve leetcode ' + p.title + ' ' + p.difficulty + ' solution')}`;
        const yt = `https://www.youtube.com/results?search_query=${encodeURIComponent('LeetCode ' + p.title + ' solution')}`;
        const topics = (p.topicTags || []).slice(0, 3).map(t => t.name || t).join(' · ');
        return `<tr class="${slv ? 'solved' : ''} ${fv ? 'fav' : ''}">
                    <td class="chk-cell"><input type="checkbox" ${slv ? 'checked' : ''} onchange="toggleSolvedHandler('${pid}', this)"></td>
                    <td class="fav-cell"><button class="${fv ? 'active' : ''}" onclick="toggleFavoriteAPI('${pid}')">${fv ? '★' : '☆'}</button></td>
                    <td style="color:var(--text-muted);font-size:0.65rem;">${pid}</td>
                    <td><a href="${lc}" target="_blank" class="prob-link">${p.title}</a><span class="topic-mini">${topics}</span></td>
                    <td><span class="diff-tag diff-${p.difficulty}">${p.difficulty.substring(0, 3)}</span></td>
                    <td><div class="actions">
                        <a href="${lc}" target="_blank" class="act-btn lc" title="Solve"><i class="fas fa-external-link-alt"></i></a>
                        <a href="${ai}" target="_blank" class="act-btn ai" title="AI Solve"><i class="fas fa-wand-magic-sparkles"></i></a>
                        <a href="${yt}" target="_blank" class="act-btn yt" title="YouTube"><i class="fab fa-youtube"></i></a>
                    </div></td>
                </tr>`;
    }).join('');
}

function toggleSolvedHandler(pid, checkbox) {
    const problem = window.allProblems.find(p => (p.frontendQuestionId || p.titleSlug) === pid);
    if (problem) toggleSolvedAPI(pid, problem, checkbox);
}

function renderPagination(total) {
    const pg = document.getElementById('pagination');
    if (total <= 1) { pg.innerHTML = ''; return; }
    let h = `<button class="page-btn" onclick="goPage(${curPage - 1})" ${curPage === 1 ? 'disabled' : ''}>←</button>`;
    const max = 7;
    let s = Math.max(1, curPage - Math.floor(max / 2));
    let e = Math.min(total, s + max - 1);
    if (e - s < max - 1) s = Math.max(1, e - max + 1);
    if (s > 1) { h += `<button class="page-btn" onclick="goPage(1)">1</button>`; if (s > 2) h += '<span class="page-btn" style="opacity:0.4;">…</span>'; }
    for (let i = s; i <= e; i++) h += `<button class="page-btn ${i === curPage ? 'active' : ''}" onclick="goPage(${i})">${i}</button>`;
    if (e < total) { if (e < total - 1) h += '<span class="page-btn" style="opacity:0.4;">…</span>'; h += `<button class="page-btn" onclick="goPage(${total})">${total}</button>`; }
    h += `<button class="page-btn" onclick="goPage(${curPage + 1})" ${curPage === total ? 'disabled' : ''}>→</button>`;
    pg.innerHTML = h;
}

function goPage(n) { curPage = n; applyFilters(); window.scrollTo({ top: 0, behavior: 'smooth' }); }

function updateStats() {
    const all = window.allProblems;
    document.getElementById('sEasy').textContent = all.filter(p => p.difficulty === 'Easy').length;
    document.getElementById('sMedium').textContent = all.filter(p => p.difficulty === 'Medium').length;
    document.getElementById('sHard').textContent = all.filter(p => p.difficulty === 'Hard').length;
    document.getElementById('sFav').textContent = serverFavs.size;
    document.getElementById('sToday').textContent = serverStreak;
    document.getElementById('sSolved').textContent = serverSolved.size;
    document.getElementById('hdrSolved').textContent = serverSolved.size;
}

function renderFavsSidebar() {
    const fl = document.getElementById('favList');
    const fp = window.allProblems.filter(p => serverFavs.has(p.frontendQuestionId || p.titleSlug));
    if (!fp.length) { fl.innerHTML = '<div style="font-size:0.65rem;color:var(--text-muted);text-align:center;">No favorites</div>'; return; }
    fl.innerHTML = fp.slice(0, 20).map(p => {
        const pid = p.frontendQuestionId || p.titleSlug;
        return `<div class="fav-item"><a href="https://leetcode.com/problems/${p.titleSlug}/" target="_blank">#${pid} ${p.title.substring(0, 22)}</a><button class="fav-rm" onclick="toggleFavoriteAPI('${pid}');renderFavsSidebar();">✕</button></div>`;
    }).join('');
    if (fp.length > 20) fl.innerHTML += `<div style="font-size:0.6rem;color:var(--text-muted);text-align:center;">+${fp.length - 20} more</div>`;
}

// ═══════════════════════════════════════
// INIT & EVENT LISTENERS
// ═══════════════════════════════════════
async function init() {
    try {
        const res = await fetch('problems.json');
        if (!res.ok) throw new Error('HTTP ' + res.status);
        window.allProblems = await res.json();
    } catch (e) {
        document.getElementById('tableBody').innerHTML = '<tr><td colspan="6" style="text-align:center;padding:50px;color:var(--hard);">⚠️ problems.json not found!</td></tr>';
        return;
    }
    document.getElementById('hdrTotal').textContent = window.allProblems.length;
    buildPatterns();
    setPOTD();

    const gsiReady = await waitForGoogleLibrary();
    if (localStorage.getItem('dsa_user') && !localStorage.getItem('dsa_token') && gsiReady) {
        const token = await attemptSilentToken();
        if (token) { location.reload(); return; }
    }
    await loadUserData();
}

function setPOTD() {
    const potd = getCurrentPotd();
    if (!potd) return;
    const lc = `https://leetcode.com/problems/${potd.titleSlug}/`;
    document.getElementById('potdTitle').textContent = potd.title;
    document.getElementById('potdMeta').textContent = `${potd.difficulty} · ${(potd.topicTags || []).map(t => t.name).join(', ')}`;
    document.getElementById('potdSolve').href = lc;
    document.getElementById('potdAI').href = `https://www.google.com/aimode?q=${encodeURIComponent('solve leetcode ' + potd.title + ' ' + potd.difficulty + ' solution')}`;
    document.getElementById('potdYT').href = `https://www.youtube.com/results?search_query=${encodeURIComponent('LeetCode ' + potd.title + ' solution')}`;
    document.getElementById('hdrPOTD').href = lc;
    document.getElementById('hdrAI').href = '#';
}

document.getElementById('searchInput').addEventListener('input', function () { curSearch = this.value; curPage = 1; applyFilters(); });
document.getElementById('diffFilter').addEventListener('change', function () { curDiff = this.value; curPage = 1; applyFilters(); });

function clearAll() {
    document.getElementById('searchInput').value = '';
    document.getElementById('diffFilter').value = 'All';
    curSearch = ''; curDiff = 'All'; curPage = 1;
    applyFilters();
}

function toggleTheme() {
    document.body.classList.toggle('light-mode');
    const icon = document.getElementById('themeIcon');
    const isLight = document.body.classList.contains('light-mode');
    icon.className = isLight ? 'fas fa-sun' : 'fas fa-moon';
    localStorage.setItem('dsa_theme2', isLight ? 'light' : 'dark');
}
if (localStorage.getItem('dsa_theme2') === 'light') {
    document.body.classList.add('light-mode');
    document.getElementById('themeIcon').className = 'fas fa-sun';
}

function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').classList.toggle('show'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('sidebarOverlay').classList.remove('show'); }
document.getElementById('sidebarOverlay').addEventListener('click', closeSidebar);

document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); document.getElementById('searchInput').focus(); }
    if (e.key === 'Escape') closeSidebar();
});

document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && getToken()) loadUserData();
});

document.addEventListener('click', async function tokenOnClick() {
    if (localStorage.getItem('dsa_token') || !localStorage.getItem('dsa_user') || window._tokenRetrying) return;
    window._tokenRetrying = true;
    const gsiReady = await waitForGoogleLibrary(2000);
    if (gsiReady) {
        const token = await attemptSilentToken();
        if (token) location.reload();
    }
    window._tokenRetrying = false;
});

init();

